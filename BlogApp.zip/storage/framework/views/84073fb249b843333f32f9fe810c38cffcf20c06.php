<?php $__env->startSection('content'); ?>

    <div class="row px-5 justify-content-center">
        <div class="col-lg-6">

            <div class="row mb-3">
                <div class="col">
                    <h3><?php echo e($user_post->title); ?></h3>
                </div>
            </div>

            <div class="row mb-3">
                <div class="mx-3">
                    <img class="rounded-circle" src="<?php echo e(asset('assets/images/profile_pic/'.$user_post->profile_pic)); ?>"
                         width="50" height="50">
                </div>
                <div class="">
                    <div><?php echo e($user_post->user_name); ?></div>
                    <div><?php echo e($user_post->post_created_at); ?></div>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <img src="<?php echo e(asset('assets/images/blogs/'.$user_post->post_image)); ?>" alt=""
                         width="100%" height="100%">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <?php echo $user_post->post_body; ?>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogApp\resources\views/posts/full-post.blade.php ENDPATH**/ ?>